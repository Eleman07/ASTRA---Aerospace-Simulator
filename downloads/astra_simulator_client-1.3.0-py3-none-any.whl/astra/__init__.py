"""ASTRA remote HTTP client package."""
__version__ = "1.3.0"
