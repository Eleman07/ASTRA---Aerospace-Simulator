"""Small standard-library Python client for the local ASTRA v1 API."""

from __future__ import annotations

import json
import math
from urllib.error import HTTPError
from urllib.parse import urlencode
from urllib.request import Request, urlopen


class AstraAPIError(RuntimeError):
    """A structured error returned by the ASTRA HTTP API."""

    def __init__(self, status_code: int, message: str):
        self.status_code = status_code
        self.message = message
        super().__init__(f"ASTRA API HTTP {status_code}: {message}")


class AstraClient:
    def __init__(self, base_url: str = "http://127.0.0.1:8765", *,
                 timeout_s: float = 15.0, long_timeout_s: float = 300.0):
        self.base_url = base_url.rstrip("/")
        self.timeout_s = self._validate_timeout("timeout_s", timeout_s)
        self.long_timeout_s = self._validate_timeout("long_timeout_s", long_timeout_s)

    @staticmethod
    def _validate_timeout(name: str, value: float) -> float:
        if (isinstance(value, bool) or not isinstance(value, (int, float)) or
                not math.isfinite(value) or value <= 0.0):
            raise ValueError(f"{name} must be a finite positive number of seconds")
        return float(value)

    def _request(self, path: str, payload: dict | None = None, *,
                 timeout_s: float | None = None) -> dict:
        data = None if payload is None else json.dumps(payload).encode("utf-8")
        req = Request(self.base_url + path, data=data,
                      headers={"Content-Type": "application/json"} if data else {})
        timeout = self.timeout_s if timeout_s is None else self._validate_timeout(
            "timeout_s", timeout_s)
        try:
            with urlopen(req, timeout=timeout) as response:
                return json.loads(response.read().decode("utf-8"))
        except HTTPError as exc:
            try:
                raw = exc.read().decode("utf-8", errors="replace")
            finally:
                exc.close()
            try:
                body = json.loads(raw)
            except (json.JSONDecodeError, TypeError):
                body = None
            message = (body.get("error") if isinstance(body, dict) else None) or raw or exc.reason
            raise AstraAPIError(exc.code, str(message)) from exc

    def state(self) -> dict:
        return self._request("/api/v1/state")

    def status(self) -> dict:
        """Return the running engine version and advertised capabilities."""
        return self._request("/api/v1/status")

    def models(self) -> dict:
        """Return the selectable spacecraft, aircraft, and UAV catalogs."""
        return self._request("/api/v1/models")

    def engineering_models(self) -> dict:
        """List standalone Engineering Studio analysis solvers."""
        return self._request("/api/v1/engineering")

    def engineering(self, analysis: str, **parameters) -> dict:
        """Run isolated SI engineering analyses without changing the live mission.

        Solvers include orbit, lambert, lifting_line, orbit_eclipse_power, radio_link,
        propulsion, planetary_landing_6dof, beam, thermal, aircraft_trim, power and link.
        Example: sim.engineering("beam", length_m=3, tip_force_N=-700).
        """
        return self._request("/api/v1/engineering", {"analysis": analysis, **parameters},
                             timeout_s=self.long_timeout_s)

    def verify_requirements(self, requirements: list[dict]) -> dict:
        """Evaluate evidence-backed numeric predicates against the live ASTRA state."""
        return self._request("/api/v1/requirements/verify",
                             {"requirements": requirements})

    def vehicle_parts(self) -> dict:
        return self._request("/api/v1/vehicle-parts")

    def celestial(self, date: str | None = None) -> dict:
        """Return the planetary and moon catalog at a UTC reference date."""
        query = {} if date is None else {"date": date}
        suffix = "?" + urlencode(query) if query else ""
        return self._request("/api/v1/celestial" + suffix)

    def transfer(self, target_id: str, date: str | None = None) -> dict:
        """Return a Lambert-seeded, N-body targeted planetary transfer design."""
        query = {"target": target_id}
        if date is not None:
            query["date"] = date
        return self._request("/api/v1/transfer?" + urlencode(query),
                             timeout_s=self.long_timeout_s)

    def transfer_state(self, target_id: str, elapsed_s: float,
                       date: str | None = None) -> dict:
        """Return the corrected Cowell transfer or geocentric lunar state."""
        query = {"target": target_id, "elapsed_s": elapsed_s}
        if date is not None:
            query["date"] = date
        return self._request("/api/v1/transfer/state?" + urlencode(query),
                             timeout_s=self.long_timeout_s)

    def command(self, **values) -> dict:
        return self._request("/api/v1/command", values)

    def heartbeat(self) -> dict:
        """Refresh the Python control link without changing actuator setpoints."""
        return self.command(mode="python")

    def step(self, dt_s: float = 0.1) -> dict:
        return self._request("/api/v1/step", {"dt_s": dt_s})

    def reset(self, vehicle: str = "space", scenario: str = "mission",
              model_id: str | None = None,
              custom_design: dict | None = None,
              wind_ned_m_s: list[float] | tuple[float, float, float] | None = None,
              turbulence: dict | None = None,
              wind_profile_ned_m_s: list[dict] | None = None) -> dict:
        """Reset a mission; altitude wind profiles replace the uniform vector."""
        payload = {"vehicle": vehicle, "scenario": scenario,
                   "model_id": model_id}
        if custom_design is not None:
            payload["custom_design"] = custom_design
        if wind_ned_m_s is not None:
            payload["wind_ned_m_s"] = list(wind_ned_m_s)
        if turbulence is not None:
            payload["turbulence"] = turbulence
        if wind_profile_ned_m_s is not None:
            payload["wind_profile_ned_m_s"] = wind_profile_ned_m_s
        return self._request("/api/v1/reset", payload)

    def launch(self) -> dict:
        """Start the current vehicle's automatic launch/takeoff mission."""
        return self._request("/api/v1/launch", {})

    def stage(self) -> dict:
        """Manually jettison the active custom spacecraft stage."""
        return self._request("/api/v1/stage", {})

    def inject_fault(self, fault_type: str, severity_fraction: float = 0.3,
                     rotor_index: int | None = None) -> dict:
        """Inject a propulsion fault or barometer/GNSS outage in the live case."""
        payload = {"type": fault_type}
        if fault_type not in {"barometer_dropout", "gnss_dropout"}:
            payload["severity_fraction"] = severity_fraction
        if rotor_index is not None:
            payload["rotor_index"] = rotor_index
        return self._request("/api/v1/fault", payload)

    def clear_faults(self) -> dict:
        """Clear active injected faults while preserving their event history."""
        return self._request("/api/v1/fault/clear", {})

    def robustness(self, *, vehicle: str = "space", scenario: str = "mission",
                   model_id: str | None = None, samples: int = 8,
                   seed: int = 20261023,
                   custom_design: dict | None = None,
                   baseline_turbulence: dict | None = None,
                   baseline_wind_profile_ned_m_s: list[dict] | None = None,
                   baseline_wind_ned_m_s: list[float] | None = None) -> dict:
        """Run a seeded Monte Carlo campaign with optional uniform or profile wind."""
        payload = {"vehicle": vehicle, "scenario": scenario,
                   "model_id": model_id, "samples": samples, "seed": seed}
        if custom_design is not None:
            payload["custom_design"] = custom_design
        if baseline_turbulence is not None:
            payload["baseline_turbulence"] = baseline_turbulence
        if baseline_wind_profile_ned_m_s is not None:
            payload["baseline_wind_profile_ned_m_s"] = baseline_wind_profile_ned_m_s
        if baseline_wind_ned_m_s is not None:
            payload["baseline_wind_ned_m_s"] = baseline_wind_ned_m_s
        return self._request("/api/v1/robustness", payload,
                             timeout_s=self.long_timeout_s)

    def convergence(self, *, vehicle: str = "space", scenario: str = "mission",
                    model_id: str | None = None, horizon_s: float | None = None,
                    base_step_s: float | None = None, levels: int = 4,
                    custom_design: dict | None = None,
                    baseline_wind_ned_m_s: list[float] | None = None,
                    baseline_turbulence: dict | None = None,
                    baseline_wind_profile_ned_m_s: list[dict] | None = None,
                    tolerances: dict[str, float] | None = None) -> dict:
        """Compare an isolated mission across RK4 refinements and declared tolerances.

        Tolerances may include ``peak_dynamic_pressure_relative_pct`` in addition
        to position, velocity, altitude, attitude, resources and event timing.
        """
        payload = {"vehicle": vehicle, "scenario": scenario, "model_id": model_id,
                   "levels": levels}
        if horizon_s is not None:
            payload["horizon_s"] = horizon_s
        if base_step_s is not None:
            payload["base_step_s"] = base_step_s
        if custom_design is not None:
            payload["custom_design"] = custom_design
        if baseline_wind_ned_m_s is not None:
            payload["baseline_wind_ned_m_s"] = baseline_wind_ned_m_s
        if baseline_turbulence is not None:
            payload["baseline_turbulence"] = baseline_turbulence
        if baseline_wind_profile_ned_m_s is not None:
            payload["baseline_wind_profile_ned_m_s"] = baseline_wind_profile_ned_m_s
        if tolerances is not None:
            payload["tolerances"] = tolerances
        return self._request("/api/v1/convergence", payload,
                             timeout_s=self.long_timeout_s)


if __name__ == "__main__":
    sim = AstraClient()
    sim.reset("space")
    sim.launch()
    while True:
        state = sim.step(0.1)
        print(f"t={state['time_s']:7.2f}s  h={state['altitude_m']/1000:8.3f} km  "
              f"v={state['speed_m_s']/1000:7.4f} km/s")
        if state["phase"] in {"LANDED", "CRASHED", "ABORTED"}:
            break
